"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { ShoppingBag, X, Plus, Minus } from "lucide-react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"

// Initialize EmailJS
declare global {
  interface Window {
    emailjs: any
  }
}

export default function Home() {
  const [selectedProduct, setSelectedProduct] = useState<{
    name: string
    price: number
  } | null>(null)
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [quantity, setQuantity] = useState(1)
  const formRef = useRef<HTMLFormElement>(null)
  const orderFormRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Load EmailJS script dynamically if it's not already loaded
    if (typeof window !== "undefined" && !window.emailjs) {
      const script = document.createElement("script")
      script.src = "https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js"
      script.async = true
      script.onload = () => {
        window.emailjs.init("jFuMwTVhQAsdZIY1M")
      }
      document.body.appendChild(script)
    } else if (typeof window !== "undefined" && window.emailjs) {
      window.emailjs.init("jFuMwTVhQAsdZIY1M")
    }
  }, [])

  const handleOrderClick = (product: string, price: number) => {
    setSelectedProduct({ name: product, price })
    setShowOrderForm(true)
    setTimeout(() => {
      orderFormRef.current?.scrollIntoView({ behavior: "smooth" })
    }, 100)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (typeof window !== "undefined" && window.emailjs && formRef.current) {
      // Add the quantity to the form data
      const formData = new FormData(formRef.current)
      formData.append("quantity", quantity.toString())

      // Convert FormData to a format EmailJS can use
      const templateParams = {}
      formData.forEach((value, key) => {
        templateParams[key] = value
      })

      window.emailjs.send("service_hn14c73", "template_6qkcn13", templateParams).then(
        () => {
          alert("Ваш заказ отправлен!")
          if (formRef.current) formRef.current.reset()
          setShowOrderForm(false)
          setQuantity(1)
        },
        (error: any) => {
          alert("Ошибка... " + JSON.stringify(error))
        },
      )
    } else {
      alert("Ошибка: EmailJS не загружен. Пожалуйста, обновите страницу и попробуйте снова.")
    }
  }

  const products = [
    {
      name: "Чёрная карточница",
      price: 2990,
      image: "/images/black-goyard.webp",
    },
    {
      name: "Зелёная карточница",
      price: 2990,
      image: "/images/green-goyard.webp",
    },
    {
      name: "Синяя карточница",
      price: 2990,
      image: "/images/blue-goyard.webp",
    },
  ]

  return (
    <main className="min-h-screen bg-white text-black">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
        className="relative h-[540px] flex items-center justify-center overflow-hidden bg-black"
      >
        <div className="absolute inset-0 opacity-20 bg-[url('/images/goyard-pattern.png')] bg-repeat"></div>
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-center z-10 px-4"
        >
          <h1 className="text-4xl md:text-6xl font-extralight tracking-[0.2em] text-white mb-4">GOYARD</h1>
          <p className="text-sm md:text-base font-thin tracking-widest text-white/80">ИЗЫСКАННЫЕ АКСЕССУАРЫ</p>
        </motion.div>
      </motion.div>

      {/* Products Section */}
      <div className="w-[1800px] mx-auto px-4 py-16">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-2xl font-extralight tracking-wider text-center mb-16"
        >
          КАРТОЧНИЦЫ ПРЕМИУМ КЛАССА
        </motion.h2>

        <div className="grid grid-cols-3 gap-16">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
            >
              <Card className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow duration-300">
                <div className="relative group">
                  <div className="overflow-hidden">
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      transition={{ duration: 0.4 }}
                      className="aspect-square relative"
                    >
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        fill
                        className="object-cover"
                      />
                    </motion.div>
                  </div>
                  <motion.div
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 transition-opacity duration-300"
                  >
                    <Button
                      variant="outline"
                      className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20 hover:text-white"
                      onClick={() => handleOrderClick(product.name, product.price)}
                    >
                      <ShoppingBag className="mr-2 h-4 w-4" />
                      Заказать
                    </Button>
                  </motion.div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-light tracking-wide">{product.name}</h3>
                  <div className="flex justify-between items-center mt-2">
                    <p className="text-sm font-light">{product.price.toLocaleString()}₸</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs hover:bg-black hover:text-white"
                      onClick={() => handleOrderClick(product.name, product.price)}
                    >
                      Заказать
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Order Form */}
      <div ref={orderFormRef}>
        <AnimatePresence>
          {showOrderForm && (
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.5 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
                className="bg-white rounded-lg shadow-2xl max-w-md w-full overflow-hidden"
              >
                <div className="flex justify-between items-center p-6 border-b">
                  <h2 className="text-xl font-light tracking-wide">Оформление заказа</h2>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setShowOrderForm(false)}
                    className="rounded-full hover:bg-gray-100"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                <div className="p-6">
                  {selectedProduct && (
                    <div className="mb-6 pb-6 border-b">
                      <p className="text-sm font-light mb-2">Товар:</p>
                      <div className="flex justify-between">
                        <p className="font-medium">{selectedProduct.name}</p>
                        <p>{selectedProduct.price.toLocaleString()}₸</p>
                      </div>
                      <div className="flex items-center mt-4">
                        <p className="text-sm font-light mr-4">Количество:</p>
                        <div className="flex items-center">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="mx-3 w-8 text-center">{quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 rounded-full"
                            onClick={() => setQuantity(quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex justify-between mt-4 pt-4 border-t">
                        <p className="font-medium">Итого:</p>
                        <p className="font-medium">{(selectedProduct.price * quantity).toLocaleString()}₸</p>
                      </div>
                    </div>
                  )}

                  <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
                    <input type="hidden" name="product_name" value={selectedProduct?.name} />
                    <input type="hidden" name="product_price" value={selectedProduct?.price} />
                    <input type="hidden" name="quantity" value={quantity} />

                    <div className="space-y-2">
                      <Label htmlFor="first_name" className="text-sm font-light">
                        Имя
                      </Label>
                      <Input
                        id="first_name"
                        name="first_name"
                        required
                        pattern="[A-Za-zА-Яа-яЁё\\s\\-]{2,}"
                        title="Только буквы"
                        className="font-light"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="last_name" className="text-sm font-light">
                        Фамилия
                      </Label>
                      <Input
                        id="last_name"
                        name="last_name"
                        required
                        pattern="[A-Za-zА-Яа-яЁё\\s\\-]{2,}"
                        title="Только буквы"
                        className="font-light"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-sm font-light">
                        Телефон
                      </Label>
                      <Input
                        id="phone"
                        name="phone"
                        required
                        pattern="[+0-9\\s\\-]+"
                        title="Введите только цифры, + или -"
                        className="font-light"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address" className="text-sm font-light">
                        Адрес
                      </Label>
                      <Input id="address" name="address" required className="font-light" />
                    </div>

                    <Button type="submit" className="w-full mt-6 bg-black text-white hover:bg-black/90">
                      Оформить заказ
                    </Button>
                  </form>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </main>
  )
}
