import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({
  subsets: ["latin", "cyrillic"],
  variable: "--font-inter",
})

export const metadata: Metadata = {
  title: "Goyard Shop | Премиум карточницы",
  description: "Эксклюзивные карточницы Goyard высокого качества",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ru" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
        (function() {
          function loadEmailJS() {
            if (window.emailjs) {
              window.emailjs.init("jFuMwTVhQAsdZIY1M");
              return;
            }
            
            var script = document.createElement('script');
            script.src = "https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js";
            script.async = true;
            script.onload = function() {
              window.emailjs.init("jFuMwTVhQAsdZIY1M");
            };
            document.body.appendChild(script);
          }
          
          if (document.readyState === 'complete') {
            loadEmailJS();
          } else {
            window.addEventListener('load', loadEmailJS);
          }
        })();
      `,
          }}
        />
      </head>
      <body className={`${inter.variable} font-sans`}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false} disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
